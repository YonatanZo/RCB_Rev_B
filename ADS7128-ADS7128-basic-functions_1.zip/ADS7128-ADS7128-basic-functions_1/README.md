# ADS7128
a arduino/esp library for the ADS7128 8-Channel 12Bit I²C ADC
